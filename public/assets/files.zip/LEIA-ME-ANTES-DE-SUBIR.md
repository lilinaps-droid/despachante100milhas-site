# O que subir e o que fazer — Agenda oficial + Simulador PCD

## 1. Arquivos (github.com/lilinaps-droid/despachante100milhas-site)

| Arquivo | Onde vai | |
|---|---|---|
| `gerar.py` | raiz | substitui |
| `worker.js` | raiz | substitui |
| `simulador-pcd.js` | `public/assets/` | **novo** |
| `agenda-painel.js` | `public/assets/` | **novo** |
| `agenda.js` | `public/assets/` | substitui |
| `central.js` | `public/assets/` | substitui |
| `estilo.css` | `public/assets/` | substitui |
| `sitemap.xml` | `public/` | substitui |

Não precisa subir os `index.html` — eles nascem do `gerar.py`.

---

## 2. Banco de dados — rodar UMA vez (obrigatório)

A tabela `agendamentos` precisa de uma coluna nova (`tipo`), para separar
**cliente** de **compromisso seu**.

Cloudflare → **Workers & Pages → D1 → `agenda-100milhas` → Console**, e cole:

```sql
ALTER TABLE agendamentos ADD COLUMN tipo TEXT NOT NULL DEFAULT 'cliente';
```

Se aparecer erro dizendo que a coluna já existe, está tudo certo — pule.

> Se a tabela ainda não tiver a trava de horário único, rode também:
> ```sql
> CREATE UNIQUE INDEX IF NOT EXISTS idx_slot ON agendamentos (dia, hora);
> ```
> É ela que impede dois clientes marcarem o mesmo horário.

---

## 3. Senha do painel — só você faz (obrigatório)

O painel `/agenda` **fica trancado até você criar a senha**. Ela nunca entra no
código; vira um *secret* do Worker.

Cloudflare → **Workers & Pages → Worker `odd-hall-da24` → Settings → Variables and
Secrets → Add → Encrypt**:

- **Nome:** `AGENDA_SENHA`
- **Valor:** a senha que você quiser

Escolha uma senha só sua. **Eu não coloco senha por você — isso é seu, e tem que continuar sendo.**

---

## 4. Como usar a agenda no dia a dia

**Você entra em:** `despachante100milhas.com.br/agenda`
(não aparece no menu, não aparece no Google)

Lá você:
- **vê** todos os clientes agendados, com WhatsApp clicável;
- **lança os seus compromissos** (os que estão no seu Google Agenda) — e o horário
  some do site na mesma hora, então nenhum cliente marca por cima;
- **cancela** e o horário volta a ficar livre;
- **manda qualquer compromisso para o Google Agenda** com um clique.

**Dias de atendimento:** quarta, quinta e sexta. Segunda e terça ficaram livres.
**Horários:** 09:00 às 11:40 e 14:00 às 16:40, de 40 em 40 minutos.

---

## 5. A regra que não dá para esquecer

O site **não enxerga** o seu Google Agenda. A ligação é de mão única (daqui pra lá).

Então: **compromisso que ocupa quarta, quinta ou sexta precisa ser lançado no painel.**
Se não for, o site continua oferecendo aquele horário para o cliente.

Nos outros dias não tem risco — o site nem oferece.
